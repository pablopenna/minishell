#ifndef __MINISHELL_INPUT_H__ 
#define __MINISHELL_INPUT_H__ 

void print_prompt();
void read_command_line(char *buf);

#endif // __MINISHELL_INPUT_H__ 
