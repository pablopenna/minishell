#ifndef __EXECUTE_H__
#define __EXECUTE_H__

void execute_external_command(const char *command);

#endif // __EXECUTE_H__
