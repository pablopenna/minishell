#ifndef __FREE_ARGS_H__
#define __FREE_ARGS_H__

void parser_free_args(char **args);

#endif // __FREE_ARGS_H__
