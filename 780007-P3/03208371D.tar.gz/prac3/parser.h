#ifndef __PARSER_H__ 
#define __PARSER_H__ 

char ** parser_command(const char *orden, int *background);

#endif // __PARSER_H__ 
