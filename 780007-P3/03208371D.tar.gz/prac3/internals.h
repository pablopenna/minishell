#ifndef __INTERNALS_H__
#define __INTERNALS_H__

int is_internal_command(const char *);
void execute_internal_command(const char *);

#endif // __INTERNALS_H__
